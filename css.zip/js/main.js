// Mahavir Enterprise - Main Scripts

document.addEventListener('DOMContentLoaded', () => {
  // 1. Sticky Navbar styling on scroll
  const navbar = document.querySelector('.custom-navbar');
  if (navbar) {
    window.addEventListener('scroll', () => {
      if (window.scrollY > 30) {
        navbar.classList.add('scrolled');
      } else {
        navbar.classList.remove('scrolled');
      }
    });
  }

  // 2. Active nav link highlight on scroll
  const sections = document.querySelectorAll('section[id]');
  const navLinks = document.querySelectorAll('.nav-link');

  window.addEventListener('scroll', () => {
    let current = '';
    sections.forEach(section => {
      const sectionTop = section.offsetTop - 120;
      if (window.scrollY >= sectionTop) {
        current = section.getAttribute('id');
      }
    });

    navLinks.forEach(link => {
      link.classList.remove('active');
      if (link.getAttribute('href') === `#${current}`) {
        link.classList.add('active');
      }
    });
  });

  // 3. Interactive Location Map Switcher
  const tabAhmedabad = document.getElementById('tabAhmedabad');
  const tabChhota = document.getElementById('tabChhota');
  const gmapFrame = document.getElementById('gmapFrame');
  const mapLocationCaption = document.getElementById('mapLocationCaption');
  const mapDirectLink = document.getElementById('mapDirectLink');

  if (tabAhmedabad && tabChhota && gmapFrame) {
    const locations = {
      ahmedabad: {
        embed: 'https://maps.google.com/maps?q=208,+Swati+Apartment,+Nehrunagar+Char+Rasta,+Ambavadi,+Ahmedabad,+Gujarat+380015&t=&z=15&ie=UTF8&iwloc=&output=embed',
        caption: 'Corporate Office: Ambavadi, Ahmedabad - 380 015',
        direct: 'https://maps.google.com/?q=208,+Swati+Apartment,+Nehrunagar+Char+Rasta,+Ambavadi,+Ahmedabad,+Gujarat+380015'
      },
      chhota: {
        embed: 'https://maps.google.com/maps?q=Station+Road,+Chhota+Udepur,+Gujarat+391165&t=&z=15&ie=UTF8&iwloc=&output=embed',
        caption: 'Collection Centre: Station Road, Chotta Udepur - 391 165',
        direct: 'https://maps.google.com/?q=Station+Road,+Chhota+Udepur,+Gujarat+391165'
      }
    };

    tabAhmedabad.addEventListener('click', () => {
      tabAhmedabad.classList.add('active');
      tabChhota.classList.remove('active');
      gmapFrame.src = locations.ahmedabad.embed;
      if (mapLocationCaption) {
        mapLocationCaption.innerHTML = `<i class="bi bi-info-circle-fill text-muted"></i> <span>${locations.ahmedabad.caption}</span>`;
      }
      if (mapDirectLink) {
        mapDirectLink.href = locations.ahmedabad.direct;
      }
    });

    tabChhota.addEventListener('click', () => {
      tabChhota.classList.add('active');
      tabAhmedabad.classList.remove('active');
      gmapFrame.src = locations.chhota.embed;
      if (mapLocationCaption) {
        mapLocationCaption.innerHTML = `<i class="bi bi-info-circle-fill text-muted"></i> <span>${locations.chhota.caption}</span>`;
      }
      if (mapDirectLink) {
        mapDirectLink.href = locations.chhota.direct;
      }
    });
  }

  // 4. Mobile Navbar Hamburger <-> 'X' toggle & Auto-collapse
  const navbarCollapse = document.getElementById('navbarMain');
  const navbarToggler = document.querySelector('.navbar-toggler');

  if (navbarCollapse) {
    if (navbarToggler) {
      navbarCollapse.addEventListener('show.bs.collapse', () => {
        navbarToggler.classList.remove('collapsed');
        navbarToggler.setAttribute('aria-expanded', 'true');
      });

      navbarCollapse.addEventListener('hidden.bs.collapse', () => {
        navbarToggler.classList.add('collapsed');
        navbarToggler.setAttribute('aria-expanded', 'false');
      });
    }

    navLinks.forEach(link => {
      link.addEventListener('click', () => {
        if (window.innerWidth < 992 && navbarCollapse.classList.contains('show')) {
          if (typeof bootstrap !== 'undefined' && bootstrap.Collapse) {
            const bsCollapse = bootstrap.Collapse.getInstance(navbarCollapse) || new bootstrap.Collapse(navbarCollapse, { toggle: false });
            bsCollapse.hide();
          }
        }
      });
    });
  }

  // 5. Current Year
  const yearEl = document.getElementById('currentYear');
  if (yearEl) {
    yearEl.textContent = new Date().getFullYear();
  }
});
